<?php

namespace App\Http\Controllers;

use App\Models\Lugar;
use Illuminate\Http\Request;

/**
 * CONTROLADOR (C): recibe la petición, pide datos al modelo
 * y decide qué vista devolver.
 */
class LugarController extends Controller
{
    /** GET /lugares  -> listado (con filtros opcionales). */
    public function index(Request $request)
    {
        $lugares = Lugar::all();

        if ($request->filled('departamento')) {
            $lugares = $lugares->where('departamento', $request->input('departamento'));
        }

        if ($request->filled('categoria')) {
            $lugares = $lugares->where('categoria', $request->input('categoria'));
        }

        return view('lugares.index', [
            'lugares'       => $lugares->values(),
            'departamentos' => Lugar::departamentos(),
            'categorias'    => Lugar::categorias(),
            'filtros'       => $request->only(['departamento', 'categoria']),
        ]);
    }

    /** GET /lugares/{id}  -> detalle de un lugar. */
    public function show(int $id)
    {
        $lugar = Lugar::find($id);

        abort_if(is_null($lugar), 404, 'El lugar turístico solicitado no existe.');

        return view('lugares.show', ['lugar' => $lugar]);
    }
}
