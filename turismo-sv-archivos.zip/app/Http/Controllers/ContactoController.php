<?php

namespace App\Http\Controllers;

use App\Models\Contacto;
use App\Models\Lugar;
use Illuminate\Http\Request;

class ContactoController extends Controller
{
    /** GET /contacto  -> muestra el formulario (opcionalmente con un lugar preseleccionado). */
    public function create(Request $request)
    {
        return view('contacto.create', [
            'lugares'      => Lugar::all(),
            'lugarElegido' => $request->query('lugar'),
        ]);
    }

    /** POST /contacto  -> valida y guarda el mensaje. */
    public function store(Request $request)
    {
        $datos = $request->validate([
            'nombre'   => ['required', 'string', 'max:100'],
            'email'    => ['required', 'email', 'max:150'],
            'telefono' => ['nullable', 'string', 'max:20'],
            'lugar_id' => ['nullable', 'integer'],
            'mensaje'  => ['required', 'string', 'min:10', 'max:1000'],
        ]);

        Contacto::guardar($datos);

        return redirect()
            ->route('contacto.create')
            ->with('exito', '¡Gracias! Recibimos tu solicitud y te contactaremos pronto.');
    }
}
