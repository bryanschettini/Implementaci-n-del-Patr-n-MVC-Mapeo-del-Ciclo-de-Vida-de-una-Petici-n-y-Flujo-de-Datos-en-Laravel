<?php

namespace App\Models;

use Illuminate\Support\Collection;

/**
 * MODELO (M): encapsula el acceso a los datos.
 * En lugar de una base de datos, la fuente de datos es un archivo JSON.
 * El controlador NUNCA lee el archivo directamente: siempre pasa por el modelo.
 */
class Lugar
{
    private static function ruta(): string
    {
        return database_path('data/lugares.json');
    }

    /** Devuelve todos los lugares como colección de arreglos. */
    public static function all(): Collection
    {
        if (! is_file(self::ruta())) {
            return collect();
        }

        $datos = json_decode(file_get_contents(self::ruta()), true);

        return collect(is_array($datos) ? $datos : []);
    }

    /** Busca un lugar por id; retorna null si no existe. */
    public static function find(int $id): ?array
    {
        return self::all()->firstWhere('id', $id);
    }

    public static function departamentos(): Collection
    {
        return self::all()->pluck('departamento')->unique()->sort()->values();
    }

    public static function categorias(): Collection
    {
        return self::all()->pluck('categoria')->unique()->sort()->values();
    }
}
