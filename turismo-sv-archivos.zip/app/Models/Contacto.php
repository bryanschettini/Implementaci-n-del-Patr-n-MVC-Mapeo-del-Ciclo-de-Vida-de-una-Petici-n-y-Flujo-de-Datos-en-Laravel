<?php

namespace App\Models;

use Illuminate\Support\Collection;

/**
 * MODELO (M): guarda las solicitudes de contacto en un archivo JSON.
 */
class Contacto
{
    private static function ruta(): string
    {
        return database_path('data/contactos.json');
    }

    public static function all(): Collection
    {
        if (! is_file(self::ruta())) {
            return collect();
        }

        $datos = json_decode(file_get_contents(self::ruta()), true);

        return collect(is_array($datos) ? $datos : []);
    }

    /** Agrega un nuevo mensaje al archivo JSON. */
    public static function guardar(array $datos): array
    {
        $contactos = self::all();

        $registro = array_merge($datos, [
            'id'    => ($contactos->max('id') ?? 0) + 1,
            'fecha' => now()->toDateTimeString(),
        ]);

        $contactos->push($registro);

        file_put_contents(
            self::ruta(),
            json_encode($contactos->values(), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            LOCK_EX
        );

        return $registro;
    }
}
