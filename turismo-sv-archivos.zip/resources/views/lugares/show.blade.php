@extends('layouts.app')

@section('titulo', $lugar['titulo'])

@section('contenido')
    <p><a href="{{ route('lugares.index') }}">← Volver al listado</a></p>

    <article class="card">
        <h1>{{ $lugar['titulo'] }}</h1>
        <p>
            <span class="badge">{{ $lugar['departamento'] }}</span>
            <span class="badge">{{ $lugar['categoria'] }}</span>
        </p>
        <p>{{ $lugar['descripcion'] }}</p>

        <h3>Información general</h3>
        <table>
            <tr><th>Ubicación</th><td>{{ $lugar['ubicacion'] }}</td></tr>
            <tr><th>Horario</th><td>{{ $lugar['horario'] }}</td></tr>
            <tr><th>Mejor época</th><td>{{ $lugar['mejor_epoca'] }}</td></tr>
        </table>

        <h3>Precios de entrada (USD)</h3>
        <table>
            <tr><th>Adulto nacional</th><td>{{ $lugar['precios']['entrada'] > 0 ? '$' . number_format($lugar['precios']['entrada'], 2) : 'Gratis' }}</td></tr>
            <tr><th>Adulto extranjero</th><td>{{ $lugar['precios']['adulto_extranjero'] > 0 ? '$' . number_format($lugar['precios']['adulto_extranjero'], 2) : 'Gratis' }}</td></tr>
            <tr><th>Niño</th><td>{{ $lugar['precios']['nino'] > 0 ? '$' . number_format($lugar['precios']['nino'], 2) : 'Gratis' }}</td></tr>
        </table>

        <h3>Actividades</h3>
        <ul>
            @foreach ($lugar['actividades'] as $actividad)
                <li>{{ $actividad }}</li>
            @endforeach
        </ul>

        <h3>Recomendaciones</h3>
        <p>{{ $lugar['recomendaciones'] }}</p>

        <a class="btn" href="{{ route('contacto.create', ['lugar' => $lugar['id']]) }}">Solicitar más información</a>
    </article>
@endsection
