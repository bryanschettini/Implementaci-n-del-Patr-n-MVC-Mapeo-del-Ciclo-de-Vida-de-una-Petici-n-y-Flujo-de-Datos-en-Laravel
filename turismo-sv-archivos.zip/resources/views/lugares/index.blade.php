@extends('layouts.app')

@section('titulo', 'Lugares turísticos de El Salvador')

@section('contenido')
    <h1>Lugares turísticos de El Salvador</h1>

    <form method="GET" action="{{ route('lugares.index') }}" class="filtros">
        <div>
            <label for="departamento">Departamento</label>
            <select name="departamento" id="departamento">
                <option value="">Todos</option>
                @foreach ($departamentos as $dep)
                    <option value="{{ $dep }}" @selected(($filtros['departamento'] ?? '') === $dep)>{{ $dep }}</option>
                @endforeach
            </select>
        </div>
        <div>
            <label for="categoria">Categoría</label>
            <select name="categoria" id="categoria">
                <option value="">Todas</option>
                @foreach ($categorias as $cat)
                    <option value="{{ $cat }}" @selected(($filtros['categoria'] ?? '') === $cat)>{{ $cat }}</option>
                @endforeach
            </select>
        </div>
        <button class="btn" type="submit">Filtrar</button>
        <a class="btn btn-sec" href="{{ route('lugares.index') }}">Limpiar</a>
    </form>

    @if ($lugares->isEmpty())
        <div class="card">No se encontraron lugares con esos filtros.</div>
    @else
        <div class="grid">
            @foreach ($lugares as $lugar)
                <article class="card">
                    <h2>{{ $lugar['titulo'] }}</h2>
                    <p>
                        <span class="badge">{{ $lugar['departamento'] }}</span>
                        <span class="badge">{{ $lugar['categoria'] }}</span>
                    </p>
                    <p>{{ \Illuminate\Support\Str::limit($lugar['descripcion'], 110) }}</p>
                    <p>
                        <strong>Entrada:</strong>
                        {{ $lugar['precios']['entrada'] > 0 ? '$' . number_format($lugar['precios']['entrada'], 2) : 'Gratis' }}
                    </p>
                    <a class="btn" href="{{ route('lugares.show', $lugar['id']) }}">Ver detalle</a>
                </article>
            @endforeach
        </div>
    @endif
@endsection
