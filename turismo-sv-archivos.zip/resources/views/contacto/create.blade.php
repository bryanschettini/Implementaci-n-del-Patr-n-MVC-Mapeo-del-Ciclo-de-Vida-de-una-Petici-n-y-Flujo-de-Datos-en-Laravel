@extends('layouts.app')

@section('titulo', 'Contacto')

@section('contenido')
    <h1>Solicitar más información</h1>

    @if (session('exito'))
        <div class="ok">{{ session('exito') }}</div>
    @endif

    <form class="card" method="POST" action="{{ route('contacto.store') }}">
        @csrf

        <label for="nombre">Nombre</label>
        <input type="text" id="nombre" name="nombre" value="{{ old('nombre') }}">
        @error('nombre') <div class="error">{{ $message }}</div> @enderror

        <label for="email">Correo electrónico</label>
        <input type="email" id="email" name="email" value="{{ old('email') }}">
        @error('email') <div class="error">{{ $message }}</div> @enderror

        <label for="telefono">Teléfono (opcional)</label>
        <input type="text" id="telefono" name="telefono" value="{{ old('telefono') }}">
        @error('telefono') <div class="error">{{ $message }}</div> @enderror

        <label for="lugar_id">Lugar de interés (opcional)</label>
        <select id="lugar_id" name="lugar_id">
            <option value="">— Selecciona —</option>
            @foreach ($lugares as $lugar)
                <option value="{{ $lugar['id'] }}" @selected((string) old('lugar_id', $lugarElegido) === (string) $lugar['id'])>
                    {{ $lugar['titulo'] }}
                </option>
            @endforeach
        </select>

        <label for="mensaje">Mensaje</label>
        <textarea id="mensaje" name="mensaje" rows="5">{{ old('mensaje') }}</textarea>
        @error('mensaje') <div class="error">{{ $message }}</div> @enderror

        <p><button class="btn" type="submit">Enviar</button></p>
    </form>
@endsection
