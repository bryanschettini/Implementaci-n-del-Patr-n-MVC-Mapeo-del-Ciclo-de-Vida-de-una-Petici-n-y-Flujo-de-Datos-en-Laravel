<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>@yield('titulo', 'Turismo El Salvador')</title>
    <style>
        :root { --azul:#0b3d91; --claro:#f4f6fb; --texto:#1f2937; --borde:#e2e8f0; }
        * { box-sizing: border-box; }
        body { margin:0; font-family: system-ui, sans-serif; color:var(--texto); background:var(--claro); }
        header { background:var(--azul); color:#fff; padding:1rem 1.5rem; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:.5rem; }
        header a { color:#fff; text-decoration:none; margin-left:1rem; }
        header .logo { font-weight:700; font-size:1.2rem; margin:0; }
        main { max-width:1000px; margin:1.5rem auto; padding:0 1rem; }
        .grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(280px,1fr)); gap:1rem; }
        .card { background:#fff; border:1px solid var(--borde); border-radius:10px; padding:1.2rem; }
        .badge { display:inline-block; background:#dbeafe; color:var(--azul); border-radius:999px; padding:.15rem .7rem; font-size:.8rem; margin-right:.3rem; }
        .btn { display:inline-block; background:var(--azul); color:#fff; padding:.5rem 1rem; border-radius:6px; border:0; text-decoration:none; cursor:pointer; font-size:1rem; }
        .btn-sec { background:#fff; color:var(--azul); border:1px solid var(--azul); }
        table { width:100%; border-collapse:collapse; }
        th, td { text-align:left; padding:.5rem; border-bottom:1px solid var(--borde); }
        label { display:block; margin-top:.8rem; font-weight:600; }
        input, select, textarea { width:100%; padding:.5rem; border:1px solid var(--borde); border-radius:6px; font:inherit; }
        .error { color:#b91c1c; font-size:.85rem; }
        .ok { background:#dcfce7; border:1px solid #86efac; padding:.8rem; border-radius:8px; margin-bottom:1rem; }
        .filtros { display:flex; gap:.8rem; flex-wrap:wrap; align-items:end; margin-bottom:1rem; }
        .filtros div { flex:1; min-width:180px; }
        footer { text-align:center; color:#64748b; padding:2rem 1rem; font-size:.85rem; }
    </style>
</head>
<body>
    <header>
        <p class="logo">🇸🇻 Turismo El Salvador</p>
        <nav>
            <a href="{{ route('lugares.index') }}">Lugares</a>
            <a href="{{ route('contacto.create') }}">Contacto</a>
        </nav>
    </header>

    <main>
        @yield('contenido')
    </main>

    <footer>Proyecto académico · Patrón MVC en Laravel · Datos de prueba en JSON</footer>
</body>
</html>
